<?php
$koneksi = new mysqli("localhost", "root", "", "early_coffe") ;

$project_name = "early_coffe_staff";
$base_url = "http://$_SERVER[HTTP_HOST]/$project_name";
