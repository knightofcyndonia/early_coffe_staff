
Changelog :  Vuexy - Vuejs, HTML & Laravel Admin Dashboard Template
=======


V4.1 [14/11/2019]

#To maintain the consistancy, we have updated HTML and HTML - Laravel version to 4.1

- Added :
 - RTL compatibility for all versions
 - User App
 - User List
 - User Add / Edit
 - User View
 - Account Settings Page
 - Swiper Component [HTML]
 - Product Detail Page
 - Statistics Cards

- Updated :
 - Laravel core structure
 - Global Search UI include pages, files and contacts group filter
 - DataList UI Updates
 - Print Ready Invoice Page

- Fixed :
 - Reported bugs and minor design fix

V2.0 : [30/09/2019] : 
- Vuesax is now Vuexy :)

- Added :
  - Horizontal Menu with light & dark layout
  - AG Grid
  - Media Player

- Updated :
  - Updated Vendors/Libs
  - Updated to Gulp4

- Fixed :
  - Minor Bugs

V1.0 : [24/05/2019] : 
- Initial Release
