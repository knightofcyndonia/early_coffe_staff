<?php
class config  
{	
	function __construct() {
		$this->host = "localhost";
		$this->user  = "root";
		$this->pass = "";
		$this->db = "test";
        $this->projectName = "early_coffe_staff";
	}
}
