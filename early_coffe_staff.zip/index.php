<html>
    <?php 
    // include_once('header.php');
    header("location: kasir/home.php");
    exit();
    ?>

    <body>
    </body>
</html>