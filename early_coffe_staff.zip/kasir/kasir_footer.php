

    <!-- BEGIN: Vendor JS-->
    <script src="../template/app-assets/vendors/js/vendors.min.js?2"></script>
    <!-- <script src="../template/app-assets/vendors/js/charts/apexcharts.min.js?2"></script> -->
    <script src="../template/app-assets/vendors/js/extensions/dropzone.min.js?2"></script>
    <script src="../template/app-assets/vendors/js/tables/datatable/datatables.min.js?2"></script>
    <script src="../template/app-assets/vendors/js/tables/datatable/datatables.buttons.min.js?2"></script>
    <script src="../template/app-assets/vendors/js/tables/datatable/datatables.bootstrap4.min.js?2"></script>
    <script src="../template/app-assets/vendors/js/tables/datatable/buttons.bootstrap.min.js?2"></script>
    <script src="../template/app-assets/vendors/js/tables/datatable/dataTables.select.min.js?2"></script>
    <script src="../template/app-assets/vendors/js/tables/datatable/datatables.checkboxes.min.js?2"></script>
    <script src="../template/app-assets/vendors/js/extensions/sweetalert2.all.min.js?2"></script>
    <script src="../template/app-assets/vendors/js/pickers/pickadate/picker.js?2"></script>
    <script src="../template/app-assets/vendors/js/pickers/pickadate/picker.date.js?2"></script>
    <script src="../template/app-assets/vendors/js/pickers/pickadate/picker.time.js?2"></script>
    <script src="../template/app-assets/vendors/js/pickers/pickadate/legacy.js?2"></script>
    <script src="../template/app-assets/vendors/js/tables/datatable/pdfmake.min.js?2"></script>
    <script src="../template/app-assets/vendors/js/tables/datatable/vfs_fonts.js?2"></script>
    <script src="../template/app-assets/vendors/js/tables/datatable/buttons.html5.min.js?2"></script>
    <script src="../template/app-assets/vendors/js/tables/datatable/buttons.print.min.js?2"></script>
    <script src="../template/app-assets/vendors/js/tables/datatable/buttons.bootstrap.min.js?2"></script>
    <script src="../template/app-assets/vendors/js/tables/datatable/datatables.bootstrap4.min.js?2"></script>
    <!-- END: Page Vendor JS-->

    <!-- BEGIN: Theme JS-->
    <script src="../template/app-assets/js/core/app-menu.js?2"></script>
    <script src="../template/app-assets/js/core/app.js?2"></script>
    <script src="../template/app-assets/js/scripts/components.js?2"></script>
    <!-- END: Theme JS-->

    <!-- BEGIN: Page JS-->
    <script src="js/common.js?2"></script>
    <!-- END: Page JS-->